<?php

/*
Plugin Name: Mr Music Feed
Plugin URI: 
Description: This is custom plugin to read json feed and update UI. Place this shortcoe anywhare :  [twangcity_feed]
Version: 1.0.0
Author: Md. Mamunur Rasid
Author URI: https://www.upwork.com/fl/~018526cb97aef21e26
License: GPLv2
*/


add_shortcode( 'twangcity_feed',  'mr_populate_div'   );
 
function mr_populate_div($atts, $content = ""){ 
            $output = '';
            $output = '<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> ';
            $output .= '<div id="feed_show">The feed is not ready. Check Internet</div>';
            
            $output .= '<script>var $j = jQuery.noConflict();
                 $j( document ).ready(function() {
                    //console.log( "ready!" );
                     mr_ajax_trigger();
                }); 
                
function populate_feed_show(data){

        var mr_d = new Date(data.date * 1000);
        var final_html = "";
        final_html += "<div class=\"w3-container\"><div class=\"w3-responsive\">";
        final_html += "<a href=\""+data.link+"\" target=\"_blank\" ><h2>"+data.title+"</h2></a>";
        final_html += "<p>Updated on "+mr_d+"</p>";
        final_html += "<table class=\"w3-table-all w3-hoverable\">";
        final_html += "<tr><th>Title & Description</th><th>Date & Time</th></tr>";

         for (index = 0; index < data.items.length; ++index ) {
             final_html += "<tr><td>"+data.items[index].title+"<br>"+data.items[index].description+
             "</td><td>"+new Date(data.items[index].date * 1000)+"</td></tr>";

         }
        final_html += "</table>";

         final_html += "</div></div>";
         //final_html += data.title;


        //$j("#feed_show").html("<h1> this is dynamic text "+output+"</h1>");
         $j("#feed_show").html(final_html);
    }</script>';
    
            
            
            
            $output .= '<script>
                function mr_ajax_trigger(){ 
                        $j.ajax({
                            dataType: "json",
                            url: "https://control.internet-radio.com:2199/recentfeed/twangcity/json/",
                            //data: data,
                            success: populate_feed_show
                          });
                   
                }</script>';
             
            $output .= '<script>setInterval(mr_ajax_trigger, 60000);</script>';
             
            
            return $output;
            
  }
   